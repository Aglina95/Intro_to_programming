# Write your code here :-)
a = {'Copenhagen': 'Denmark', 'Helsinki': 'Finland', 'Oslo': 'Norway'}
s = "Isn't there someone missing?"
print(len(a))
print(a['Oslo'])
print(s[6:11])
print(a['Copenhagen'].upper())
print(a['Copenhagen'][5])
print(a['Helsinki'][::-1])
print(f"{s[:12]}{a['Oslo']} {s[20:]}")
