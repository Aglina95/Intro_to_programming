def people_they_know(friends_anna, friends_betty):
    # TODO: Implement me!
    # Your code comes here:
    #Linear complexity
    list_of_friends = []
    friends_dictionary = {**friends_anna, **friends_betty}
    for key in friends_dictionary.keys():
        list_of_friends.append(key)
    print(len(list_of_friends))


friends_anna = {}
#add items into dictionary
friends_anna["Cecilie"] = "annafirend1"
friends_anna["Katrine"] = "annafriend2"
friends_anna["Rasmus"] = "annafriend3"

friends_betty = {}

friends_betty["Rasmus"] = "bettyfriend1"
friends_betty["Adam"] = "bettyfriend2"

#print(friends_anna)
#print(friends_betty)
people_they_know(friends_anna, friends_betty)
